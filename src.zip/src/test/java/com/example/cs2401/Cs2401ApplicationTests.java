package com.example.cs2401;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs2401ApplicationTests {

    @Test
    void contextLoads() {
    }

}
